require 'java'

import java.lang.System;
include Java

# import java.util.Random;
import java.util.Scanner;

class Ch03SelectWinner 

#        int startingNumber;  //the starting number
#        int count;           //the number of party goers
#        int winningNumber;   //the winner
#        int min, max;        //the range of random numbers to generate

# Ruby has Random too. We need to fix this for Java.  
#  random = Random.new(); # random number generator
# one solution  
  module JavaRandom
     include_package "java.util."
  end
  
  random = JavaUtil::Random.new()
# another solution  
  java_import 'java.util.Random' do |package,name|
    "JRandom"
  end
  random = JRandom.new()

  scan = Scanner.new(System.in);

  # Get two input values
  System.out.print("Enter the starting number M:     ");
  startingNumber = scan.nextInt();

  System.out.print("Enter the number of party goers: ");
  count  = scan.nextInt();
  scan.close();

  # select the winner
  min = startingNumber + 1;
  max = startingNumber + count;

  winningNumber  = random.nextInt(max-min) + min;

  System.out.println("\nThe Winning Number is " + winningNumber.to_s);
    
end