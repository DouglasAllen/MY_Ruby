require 'java'

import java.lang.System;
include Java

# import java.lang.Math;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;
import java.lang.StringBuffer;

class Ch03PoleHeight    

#        double height;          //height of the statue
#        double distance;        //distance between points A and B
#        double alpha;           //angle measured at point A
#        double beta;            //angle measured at point B
#        double alphaRad;        //angle alpha in radians
#        double betaRad;         //angle beta in radians

  java_import 'java.lang.Math' do |package,name|
      "JMath"
  end
  
#  java_import 'java.text.DecimalFormat' do |package,name|
#        "JDecimalFormat"
#  end
    
  scanner = Scanner.new(System.in);
  scanner.useDelimiter(System.getProperty("line.separator"));
  scanner.useLocale(Locale::US);

  ## Get three input values
  System.out.print("Angle alpha (in degree):"); # try 24
  alpha = scanner.nextDouble();
 
  System.out.print("Angle beta (in degree):");  # try 23
  beta  = scanner.nextDouble();
  
  System.out.print("Distance between points A and B (feet):"); # try 5000
  distance = scanner.nextDouble();
  scanner.close();  

  # compute the height of the tower
  alphaRad = JMath.toRadians(alpha);
  betaRad  = JMath.toRadians(beta);
  # h = d sinA sinB / (sinA + sinB) (sinA - sinB)
  height = (distance * JMath.sin(alphaRad) * JMath.sin(betaRad)) /
                JMath.sqrt(JMath.sin(alphaRad + betaRad) *
                          JMath.sin(alphaRad - betaRad));

  df = DecimalFormat.new("0.000");
  a = df.format(alpha, StringBuffer.new(), FieldPosition.new(0)).to_s
  b = df.format(beta, StringBuffer.new(), FieldPosition.new(0)).to_s
  c = df.format(distance, StringBuffer.new(), FieldPosition.new(0)).to_s
  d = df.format(height, StringBuffer.new(), FieldPosition.new(0)).to_s

 
  System.out.println("\n\nEstimating the height of the pole" +
    "\n\n" +
    "Angle at point A (deg):        " + a + "\n" +
    "Angle at point B (deg):        " + b + "\n" +
    "Distance between A and B (ft): " + c + "\n" +
    "Estimated height (ft):         " + d);           
  
end