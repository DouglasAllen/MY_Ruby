require 'java'

import java.lang.System;
include Java

class Ch03Circle 

  PI = Math::PI;
  radius = 2.35;

  ##compute the area and circumference
  area          = PI * radius * radius;
  circumference = 2.0 * PI * radius;

  System.out.println("Given Radius: " + radius.to_s);
  System.out.println("Area: " + area.to_s);
  System.out.println("Circumference: " + circumference.to_s);
    
end