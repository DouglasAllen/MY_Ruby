require 'java'

import java.lang.System;
import java.text.DecimalFormat;

class Ch03Circle2
  
  PI = Math::PI;
  include Java
  df = DecimalFormat.new("0.000");
#  puts df.public_methods(false).sort

  radius = 2.35;

  ##compute the area and circumference
  area          = PI * radius * radius;
  circumference = 2.0 * PI * radius;

  System.out.println("Given Radius: #{sprintf("%#.3f", radius)}"); 
  System.out.println("Area: #{sprintf("%#.3f", area)}");
  System.out.println("Circumference: #{sprintf("%#.3f", circumference)}");
#  System.out.println("Given Radius: #{df.format(radius)}");   
#  System.out.println("Area: #{df.format(area)}");
#  System.out.println("Circumference: " + df.format(circumference).to_s);
    
end