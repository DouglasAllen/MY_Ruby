require 'java'

import java.lang.System;
include Java

import java.util.Scanner;
import java.text.DecimalFormat;

class Ch03Circle4 

  PI = 3.14159;
  TAB = "\t";
  NEWLINE = "\n";

#  double radius, area, circumference;
  
  scanner = Scanner.new(System.in);;

  df = DecimalFormat.new("0.000");

  ## Get input
  System.out.print("Enter radius: ");
  
  radius = scanner.nextDouble();
  scanner.close();

  ## Compute area and circumference
  area          = PI * radius * radius;
  circumference = 2.0 * PI * radius;

  ## Display the results
  System.out.println(
          "Given Radius:  " + TAB + df.format(radius) + NEWLINE +
          "Area:          " + TAB + df.format(area)   + NEWLINE +
          "Circumference: " + TAB + df.format(circumference));

end