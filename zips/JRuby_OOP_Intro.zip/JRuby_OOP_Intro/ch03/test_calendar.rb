require 'java'

import java.lang.System;
include Java

import java.util.Calendar;
import java.util.GregorianCalendar;

class Ch03TestCalendar 

  cal = GregorianCalendar.new();

  System.out.println(cal.getTime());
  System.out.println("");

  System.out.println("YEAR:          " + cal.get(Calendar::YEAR).to_s);
  System.out.println("MONTH:         " + (cal.get(Calendar::MONTH) +1).to_s);
  System.out.println("DATE:          " + cal.get(Calendar::DATE).to_s);

  System.out.println("DAY_OF_YEAR:   " + cal.get(Calendar::DAY_OF_YEAR).to_s);
  System.out.println("DAY_OF_MONTH:  " + cal.get(Calendar::DAY_OF_MONTH).to_s);
  System.out.println("DAY_OF_WEEK:   " + cal.get(Calendar::DAY_OF_WEEK).to_s);

  System.out.println("WEEK_OF_YEAR:  " + cal.get(Calendar::WEEK_OF_YEAR).to_s);
  System.out.println("WEEK_OF_MONTH: " + cal.get(Calendar::WEEK_OF_MONTH).to_s);

  System.out.println("AM_PM:         " + cal.get(Calendar::AM_PM).to_s);
  System.out.println("HOUR:          " + cal.get(Calendar::HOUR).to_s);
  System.out.println("HOUR_OF_DAY:   " + cal.get(Calendar::HOUR_OF_DAY).to_s);
  System.out.println("MINUTE:        " + cal.get(Calendar::MINUTE).to_s);


end