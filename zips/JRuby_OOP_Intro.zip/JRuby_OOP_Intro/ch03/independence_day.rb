require 'java'

import java.lang.System;
include Java

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;

class Ch03IndependenceDay   
  
  independenceDay = GregorianCalendar.new(1776, Calendar::JULY, 4);

  declaration = GregorianCalendar.new(1776, Calendar::AUGUST, 2); 


  sdf = SimpleDateFormat.new("EEEE");

  System.out.println("It was adopted on " +
                  sdf.format(independenceDay.getTime()));
                  
  System.out.println("It was signed on " +
                    sdf.format(declaration.getTime()) + " a month later.");

end