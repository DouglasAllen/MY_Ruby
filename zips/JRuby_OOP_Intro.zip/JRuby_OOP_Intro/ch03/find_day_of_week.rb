require 'java'

import java.lang.System;
include Java

import java.util.GregorianCalendar;
import java.util.Scanner;
import java.text.SimpleDateFormat;

class Ch03FindDayOfWeek 

#  int     year, month, day;

  cal = GregorianCalendar.new;
  sdf = SimpleDateFormat.new;

  scanner = Scanner.new(System.in);
  scanner.useDelimiter(System.getProperty("line.separator"));

  System.out.print("Year (yyyy): ");
  year      = scanner.nextInt();

  System.out.print("Month (1-12): ");
  month     = scanner.nextInt();

  System.out.print("Day (1-31): ");
  day       = scanner.nextInt();
  scanner.close();

  cal = GregorianCalendar.new(year, month-1, day);
  sdf = SimpleDateFormat.new("EEEE");

  System.out.println("");
  System.out.println("Day of Week: " + sdf.format(cal.getTime()));

end