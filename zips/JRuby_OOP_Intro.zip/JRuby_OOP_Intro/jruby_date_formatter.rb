require 'java'
import java.text.SimpleDateFormat
import java.util.Date

pattern = "EEE, MMM dd, yyyy HH:mm:ss Z"
now = Java::JavaUtil::Date
formatter = Java::JavaText::SimpleDateFormat.new(pattern)

puts formatter.format(now.new)
