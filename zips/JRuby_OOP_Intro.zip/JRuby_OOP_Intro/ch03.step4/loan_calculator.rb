require 'java'

import java.lang.System;
include Java

import java.util.Scanner;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.lang.StringBuffer;

class Ch03LoanCalculator 

#  final int MONTHS_IN_YEAR = 12;
#  
#  double  loanAmount,
#          annualInterestRate;
#
#  double  monthlyPayment,
#          totalPayment;
#  
#  double  monthlyInterestRate;
#
#  int     loanPeriod;
#
#  int     numberOfPayments;
  
  MONTHS_IN_YEAR = 12;
  
  java_import 'java.lang.Math' do |package,name|
        "JMath"
  end
  
  scanner = Scanner.new(System.in);
  scanner.useDelimiter(System.getProperty("line.separator"));
   
   # describe the program
  System.out.println("This program computes the monthly and total");
  System.out.println("payments for a given loan amount, annual ");
  System.out.println("interest rate, and loan period.");
  System.out.println("Loan amount in dollars and cents, e.g., 12345.50");
  System.out.println("Annual interest rate in percentage, e.g., 12.75");
  System.out.println("Loan period in number of years, e.g., 15");
  System.out.println("\n"); # skip two lines

   # get input values
  System.out.print("Loan Amount (Dollars+Cents): ");
  loanAmount = scanner.nextDouble();

  System.out.print("Annual Interest Rate (e.g., 9.5): ");
  annualInterestRate = scanner.nextDouble();

  System.out.print("Loan Period - # of years: ");
  loanPeriod = scanner.nextInt();
  scanner.close();

   # compute the monthly and total payments
  monthlyInterestRate = annualInterestRate / MONTHS_IN_YEAR / 100;
  numberOfPayments    = loanPeriod * MONTHS_IN_YEAR;

  monthlyPayment = (loanAmount * monthlyInterestRate) /
                   (1 - JMath.pow(1/(1 + monthlyInterestRate),
                    numberOfPayments ) );

  totalPayment  =  monthlyPayment * numberOfPayments;
   
  df = DecimalFormat.new("0.00");
  a = df.format(loanAmount, StringBuffer.new(), FieldPosition.new(0)).to_s
  b = df.format(annualInterestRate, StringBuffer.new(), FieldPosition.new(0)).to_s
  c = df.format(loanPeriod, StringBuffer.new(), FieldPosition.new(0)).to_s      
  d = df.format(monthlyPayment, StringBuffer.new(), FieldPosition.new(0)).to_s
  e = df.format(totalPayment, StringBuffer.new(), FieldPosition.new(0)).to_s
   
   #display the result
   System.out.println("");
   System.out.println("Loan Amount:          $" + a);
   System.out.println("Annual Interest Rate:  " + b + "%");
   System.out.println("Loan Period (years):   " + c);
   
   System.out.println("\n"); # //skip two lines
   System.out.println("Monthly payment is    $ " + d);
   System.out.println("  TOTAL payment is    $ " + e);
   
end