require 'java'

import java.lang.System;
include Java

import java.util.Scanner;


class Ch03LoanCalculator 

#  final int MONTHS_IN_YEAR = 12;
#  
#  double  loanAmount,
#          annualInterestRate;
#
#  double  monthlyPayment,
#          totalPayment;
#  
#  double  monthlyInterestRate;
#
#  int     loanPeriod;
#
#  int     numberOfPayments;

  MONTHS_IN_YEAR = 12;
  java_import 'java.lang.Math' do |package,name|
        "JMath"
  end
  scanner = Scanner.new(System.in);
  scanner.useDelimiter(System.getProperty("line.separator"));

  # get input values
  System.out.print("Loan Amount (Dollars+Cents): ");
  loanAmount = scanner.nextDouble();

  System.out.print("Annual Interest Rate (e.g., 9.5): ");
  annualInterestRate = scanner.nextDouble();

  System.out.print("Loan Period - # of years: ");
  loanPeriod = scanner.nextInt();
  
  # compute the monthly and total payments
  monthlyInterestRate = annualInterestRate / MONTHS_IN_YEAR / 100;
  numberOfPayments    = loanPeriod * MONTHS_IN_YEAR;
 
  monthlyPayment = (loanAmount * monthlyInterestRate) /
             (1 - JMath.pow(1/(1 + monthlyInterestRate),
              numberOfPayments ) );
 
  totalPayment  =  monthlyPayment * numberOfPayments;      
         
  # display the result
  System.out.println("");
  System.out.println("Loan Amount:          $" + loanAmount.to_s);
  System.out.println("Annual Interest Rate:  " + annualInterestRate.to_s + "%");
  System.out.println("Loan Period (years):   " + loanPeriod.to_s);
         
  System.out.println("\n"); # skip two lines
  System.out.println("Monthly payment is    $ " + monthlyPayment.to_s);
  System.out.println("  TOTAL payment is    $ " + totalPayment.to_s);         
  
  scanner.close();
end