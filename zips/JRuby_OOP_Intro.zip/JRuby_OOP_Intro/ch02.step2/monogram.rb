require 'java'

import java.util.Scanner;
import java.lang.System;
include Java

class Ch02Monogram
  
  space = JavaLang::String.new(" ");

  scanner = Scanner.new(System.in);

  scanner.useDelimiter(System.getProperty("line.separator"));
  System.out.print(System.getProperty("line.separator"));  
        
  System.out.print("Enter your full name (first, middle, last):");
        
  input = scanner.next( );
  scanner.close();
  
  System.out.println("Name entered: #{input.class}");
    
  name = JavaLang::String.new(input)
  
  # Extract first, middle, and last names
  first  = JavaLang::String.new(name.substring(0, name.indexOf(space)));
  name   = JavaLang::String.new(name.substring(name.indexOf(space)+1, name.length()));
  
  middle = JavaLang::String.new(name.substring(0, name.indexOf(space)));
  last   = JavaLang::String.new(name.substring(name.indexOf(space)+1, name.length()));
  
  # Verify the substring operations
  System.out.println("First: #{first}");
  System.out.println("Middle: #{middle}");
  System.out.println("Last: #{last}");
  
  # Compute the monogram
  monogram = JavaLang::String.new(first.substring(0, 1) +
                                  middle.substring(0, 1) +
                                  last.substring(0, 1));
  
  # Output the result
  System.out.println("Your monogram is #{monogram}");  
  
end
