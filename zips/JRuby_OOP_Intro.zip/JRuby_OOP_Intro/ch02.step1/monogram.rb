import java.util.Scanner;
import java.lang.System;

class Ch02Monogram
  
  name = String.new;

  scanner = Scanner.new(System.in);

  scanner.useDelimiter(System.getProperty("line.separator"));
        
  System.out.print("Enter your full name (first, middle, last):");
        
  name = scanner.next( );

  System.out.println("Name entered: " + name);
        
  scanner.close();
end
