require 'java'

#import java.lang.String
include Java
import java.lang.System

class Ch02StringProcessing  

  fullName = JavaLang::String.new("Decafe Latte");
  space    = JavaLang::String.new(" ");

  firstName = fullName.substring(0, fullName.indexOf(space));
  lastName  = fullName.substring(fullName.indexOf(space) + 1,
                                       fullName.length());

  System.out.println("Full Name: #{fullName}");

  System.out.println("First: " + firstName);

  System.out.println("Last: " + lastName);

  System.out.println("Your last name has #{lastName.length} characters.");
  
end    
