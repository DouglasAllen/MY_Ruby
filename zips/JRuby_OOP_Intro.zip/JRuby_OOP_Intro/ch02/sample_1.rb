require 'java'

import javax.swing.JFrame;

class Ch02Sample1  
  
  myWindow = JFrame.new();
        
  myWindow.setSize(300, 200);
        
  myWindow.setTitle("My First Java Program");
        
  myWindow.setVisible(true);

  # The following statement terminates the program
  # automatically when the frame window is closed. This way
  # you don't have to terminate the program explicitly
  # from your Java IDE after closing the window.
         
  EXIT_ON_CLOSE = 3      
  myWindow.setDefaultCloseOperation(EXIT_ON_CLOSE);
end