require 'java'

import java.util.Scanner
import java.lang.System

class Ch02Greetings    

  firstName = String.new;

  scanner = Scanner.new(System.in);
        
  System.out.print("What is your name? ");
        
  firstName = scanner.next( ); # accept characters up to, but not 
                               # including, the first space

  System.out.println( "Hi, " + firstName + ". Nice to meet you.");
        
  scanner.close();

end
