require 'java'
require 'date'

#import java.util.Date
include Java
 
import java.text.SimpleDateFormat
import java.lang.System

class Ch02DateDisplay
 
  today = JavaUtil::Date.new               
  simpleDF1 = SimpleDateFormat.new
  pattern_string = "EEEE MMMM dd, yyyy"   
  simpleDF2 = SimpleDateFormat.new(pattern_string)      
      
  System.out.println(today.toString());
#  System.out.println(today);
#  System.out.println(today.getDate());
#  System.out.println(today.getDay());
#  System.out.println(today.getHours());
#  System.out.println(today.getMinutes());
#  System.out.println(today.getMonth());
#  System.out.println(today.getSeconds());
#  System.out.println(today.getTime());
#  System.out.println(today.getTimezoneOffset());
#  System.out.println(today.getYear());
#  System.out.println(today.toGMTString());
#  System.out.println(today.toLocaleString());
#  System.out.println(today.toString());
#  System.out.println(today.getClass());  

  #Default short format display
  System.out.println("Today is " + simpleDF1.format(today) );

  #Programmer-designated long format display
  System.out.println("Today is " + simpleDF2.format(today) );

    
end