require 'java'

import java.util.Scanner;
import java.lang.System;

class Ch02RecordFiling 

  firstName, lastName = String.new;

  scanner = Scanner.new(System.in);
 
  System.out.print("Your full name: ");
        
  firstName = scanner.next( );
  lastName  = scanner.next( );
  scanner.close();

  System.out.println("Your medical record is filed under " + 
                      lastName + ", " + firstName + ".");
end
