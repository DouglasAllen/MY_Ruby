require 'java'

import javax.swing.JFrame;

class Ch02Sample    
    
  myWindow = JFrame.new();
    
  myWindow.setSize(300, 200);
    
  myWindow.setTitle("My First Java Program");
    
  myWindow.setVisible(true);
  
  EXIT_ON_CLOSE = 3
    
  myWindow.setDefaultCloseOperation(EXIT_ON_CLOSE);

end